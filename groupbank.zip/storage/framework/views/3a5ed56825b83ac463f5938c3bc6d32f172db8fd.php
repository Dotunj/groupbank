<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
    Hi,
    <br>
    <?php echo e($user->name); ?> has added you to a savings plan on GroupBank! You'll be required to renumerate the sum of N<?php echo e(number_format($plan->amount, 2, '.', ',')); ?> monthly. 
    <br>Please click on the link below or copy it into the address bar of your browser to become subscribed to the plan:
    <br>
<a href="<?php echo e(route('add.user.plan', $plan->identifier)); ?>">Register</a>
    <br/>
</div>

</body>
</html>